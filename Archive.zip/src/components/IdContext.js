// import React from 'react';

// const IdContext = React.createContext({
//   id: -1,
// });

// export default IdContext;
